
A simple react application to find movies, series and episodes. I have used the [OMDB API](http://www.omdbapi.com) and it has certain amount of limits to fetching data. I have also used the **Ant Design** for UI.

## Requirement
- [OMDB API KEY](http://www.omdbapi.com)

Run Project:-

npm install
npm start